Placeholder for Sierra Leone Time of Flight depth files. No real depth data are included.
