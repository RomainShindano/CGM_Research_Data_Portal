CGM India dummy research dataset
Device: Huawei P30 Pro
3D sensor technology: Time of Flight
Approximate children represented in the real collection: 30,000
This package contains synthetic placeholder files only. It contains no child data.
