Placeholder for Ethiopia Time of Flight depth files. No real depth data are included.
