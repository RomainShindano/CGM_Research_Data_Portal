Placeholder for Syria Stereo Vision depth files. No real depth data are included.
