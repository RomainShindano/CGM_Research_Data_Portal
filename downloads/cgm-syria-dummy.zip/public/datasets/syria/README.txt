CGM Syria dummy research dataset
Device: Intel RealSense D435i
3D sensor technology: Stereo Vision
Approximate children represented in the real collection: 3,500
This package contains synthetic placeholder files only. It contains no child data.
