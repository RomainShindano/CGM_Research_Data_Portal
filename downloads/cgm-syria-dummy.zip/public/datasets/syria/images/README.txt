Placeholder for Syria RGB image files. No real images are included in this demo package.
