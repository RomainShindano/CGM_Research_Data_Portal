Placeholder for Namibia RGB image files. No real images are included in this demo package.
